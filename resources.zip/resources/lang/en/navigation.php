<?php

return [
    'home' => 'Home',
    'account' => [
        'header' => 'CONFIGURAÇÃO DE CONTA',
        'my_account' => 'Minha Conta',
        'security_controls' => 'Controle de Segurança',
        'api_access' => 'Conta de Api',
        'my_servers' => 'Meus Servidores',
    ],
    'server' => [
        'header' => 'Servidor',
        'console' => 'Console',
        'console-pop' => 'Fullscreen Console',
        'file_management' => 'Arquivos',
        'file_browser' => 'Navegador De Arquivos',
        'create_file' => 'Criar Arquivo',
        'upload_files' => 'Upar Arquivo',
        'subusers' => 'Sub Usuário',
        'schedules' => 'Schedules',
        'configuration' => 'Configuração',
        'port_allocations' => 'Trocar Porta',
        'sftp_settings' => 'Configuração SFTP',
        'startup_parameters' => 'Inicialização',
        'databases' => 'Databases',
        'edit_file' => 'Editar Arquivos',
        'admin_header' => 'ADMINISTRAÇÃO',
        'admin' => 'CONFIGURAÇÃO DE SERVIDOR',
	'server_name' => 'Nome Do Servidor',   
],
];
