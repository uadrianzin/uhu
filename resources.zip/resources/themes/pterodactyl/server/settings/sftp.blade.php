{{-- Pterodactyl - Panel --}}
{{-- Copyright (c) 2015 - 2017 Dane Everitt <dane@daneeveritt.com> --}}

{{-- This software is licensed under the terms of the MIT license. --}}
{{-- https://opensource.org/licenses/MIT --}}
@extends('layouts.master')

@section('title')
    @lang('server.config.sftp.header')
@endsection

@section('content-header')
    <h1>@lang('server.config.sftp.header')<small>@lang('server.config.sftp.header_sub')</small></h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('index') }}">@lang('strings.home')</a></li>
        <li><a href="{{ route('server.index', $server->uuidShort) }}">{{ $server->name }}</a></li>
        <li>@lang('navigation.server.configuration')</li>
        <li class="active">@lang('navigation.server.sftp_settings')</li>
    </ol>
@endsection

@section('content')
<div class="row">
    <div class="col-xs-12">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title">@lang('Detalhes FTP')</h3>
            </div>
            <div class="box-body">
                <div class="form-group">
                    <label class="control-label">@lang('Arquivos via SFTP')</label>
                    <div>
                        <input type="text" class="form-control" readonly value="PARA ANDROID {{ $node->fqdn }}:{{ $node->daemonSFTP }}" />
                <input type="text" class="form-control" readonly value="PARA PC sftp://{{ $node->fqdn }}:{{ $node->daemonSFTP }}" /> 
 </div>
                <div class="form-group">
                    <label for="password" class="control-label">@lang('strings.username')</label>
                    <div>
                        <input type="text" class="form-control" readonly value="{{ auth()->user()->username }}.{{ $server->uuidShort }}" />
                    </div>
                </div>
            </div>
            <div>
                <h3 class="small text-muted no-margin-bottom">@lang('A SENHA É A MESMA DO SEU LOGIN NO PAINEL.                           AVISO PARA QUEM USA ANDROID EXEMPLO PARA CONECTAR O SFTP INSTALE O PROGRAMA ES FILE EXPLORER PRIMEIRO VEM O IP DEPOIS, PORTA EXEMPLO IP:PORTA NO CASO 10.0.0.1:2022 NO CASO, IP Ê 10.0.0.1 E PORTA 2022!')</h3>
              </div>
<div> 
<h3>ABAIXO ESTÁ O DOWNLOAND DO ES FILE EXPLORER</h3>
 <a href="https://es-file-explorer.br.uptodown.com/android">DOWNLOAND</a>    

 </div>
       
<div>

<h3>ABAIXO ESTÁ O DOWNLOAND DO FILEZILA PARA PC</h3>

 <a href="https://filezilla-project.org/download.php?platform=win64">DOWNLOAND</a>



 </div>



 </div>
    </div>
</div>
@endsection

@section('footer-scripts')
    @parent
    {!! Theme::js('js/frontend/server.socket.js') !!}
@endsection
